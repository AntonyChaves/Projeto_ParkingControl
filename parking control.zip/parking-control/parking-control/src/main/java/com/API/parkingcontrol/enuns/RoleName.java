package com.API.parkingcontrol.enuns;

public enum RoleName {

    ROLE_ADMIN,
    ROLE_USER;

}

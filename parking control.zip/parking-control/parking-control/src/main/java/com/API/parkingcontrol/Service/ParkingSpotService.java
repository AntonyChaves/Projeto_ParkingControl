package com.API.parkingcontrol.Service;

import com.API.parkingcontrol.Model.ParkingSpot;
import com.API.parkingcontrol.Repository.ParkingSportRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Pageable;


import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service  //////////////INUTILLLLLLL
public class ParkingSpotService {

    @Autowired
    ParkingSportRepository parkingSportRepository;

    //troca o Object pelo parkingModel e utiliza a função save do JPA para inserir o arquivo que veio
    @Transactional
    public ParkingSpot save(ParkingSpot parkingSpot) {
       return parkingSportRepository.save(parkingSpot);
    }

    //Transferi do controller pra cá, pra depois transerir do repository para cá , ainda não entendo o porquê disso
    //Utiliza o método exists da JPA que verifica se o conteúdo daquele daquele atributo já existe em outro registro
    public boolean existsByLicensePlateCar(String licensePlateCar) {
        return parkingSportRepository.existsByLicensePlateCar(licensePlateCar);
    }

    public boolean existsByParkingSpotNumber(String parkingSpotNumber) {
        return parkingSportRepository.existsByParkingSpotNumber(parkingSpotNumber);
    }

    public boolean existsByApartmentAndBlock(String apartment, String block) {
        return parkingSportRepository.existsByApartmentAndBlock(apartment,block);
    }

    public Page<ParkingSpot> findAll(Pageable pageable) {
        return parkingSportRepository.findAll(pageable);
    }

    public Optional<ParkingSpot> findById(UUID id) {
        return parkingSportRepository.findById(id);
    }

    @Transactional
    public void delete(ParkingSpot parkingSpot) {
        parkingSportRepository.delete(parkingSpot);
    }
}

package com.API.parkingcontrol.Controller;

import com.API.parkingcontrol.Model.ParkingSpot;
import com.API.parkingcontrol.Service.ParkingSpotService;
import com.API.parkingcontrol.dtos.ParkingSpotDtos;
import jakarta.validation.Valid;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RestController
@CrossOrigin(origins = "*", maxAge = 60)
@RequestMapping(value = "/parking-spot")
public class ParkingSpotController {

    @Autowired
    ParkingSpotService parkingSpotService;

    //dtos vem como parametro para garantir que os dados que o cliente mandou sejam verificados, senão nem entram na função
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @PostMapping
    public ResponseEntity<Object> saveParkingSpot(@RequestBody @Valid ParkingSpotDtos parkingSpotDtos)
    {
        if(parkingSpotService.existsByLicensePlateCar(parkingSpotDtos.getLicensePlateCar()))
        {   //Verificação se já existe alguém com a mesma placa
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Conflict: License Plate Car is already in use");
        }

        if(parkingSpotService.existsByParkingSpotNumber(parkingSpotDtos.getParkingSpotNumber()))
        {   //Verificação se já existe uma vaga com esse numero preenchida
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Conflict: Parking Spot is already in use");
        }

        if(parkingSpotService.existsByApartmentAndBlock(parkingSpotDtos.getApartment(), parkingSpotDtos.getBlock()))
        {   //Verificação se essa vaga já foi registrada em outra pessoa do condomínio, utilizando o nº do apartamento
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Conflict: Parking Spot is already registered for this apartment/block");
        }

        //var substitui o nome da variavel para deixar mais padronizado
        var parkingSpot = new ParkingSpot();
        //converte a variavel dto que venho como parametro para uma variavel model que realmente sera usada
        BeanUtils.copyProperties(parkingSpotDtos, parkingSpot);
        //seta o atributo da data pois ele não existe em dto, utiliza a hora atual
        parkingSpot.setRegistrationDate(LocalDateTime.now(ZoneId.of("UTC")));
        //retorna a resposta http com um header usando o .created e no body a função save do parkingService passando a var model como parametro
        return ResponseEntity.status(HttpStatus.CREATED).body(parkingSpotService.save(parkingSpot));
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
    @GetMapping     //Utiliza método findAll que o Service pegou do Repository
    public ResponseEntity<Page<ParkingSpot>> getAllParkingSpots(@PageableDefault(page = 0, size = 10, sort = "id", direction = Sort.Direction.ASC)Pageable pageable)
    {
        return ResponseEntity.status(HttpStatus.OK).body(parkingSpotService.findAll(pageable));
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
    @GetMapping(value = "/{id}") //Passa o ID
    public ResponseEntity<Object> getOneParkingSpot(@PathVariable(value = "id") UUID id)
    {
        //Cria uma variável Optional que irá armazenar o arquivo selecionado pelo findById
        Optional<ParkingSpot> parkingSpotOptional = parkingSpotService.findById(id);
        if (!parkingSpotOptional.isPresent())               //Verifica se o arquivo Optional existe mesmo
        {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("ParkingSpot not found."); //Caso não exista, retorna a mensagem
        }
                //Se existir, irá retornar o material (.get()) do arquivo optional
        return ResponseEntity.status(HttpStatus.OK).body(parkingSpotOptional.get());
    }

    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @DeleteMapping(value = "/{id}")
    public ResponseEntity<Object> deleteParkingSpot(@PathVariable(value = "id") UUID id)
    {
        Optional<ParkingSpot> parkingSpotOptional = parkingSpotService.findById(id);
        if (!parkingSpotOptional.isPresent())
        {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Parking Spot not found");
        }
        //Utiliza o método delete do Service, método esse que ele pega do Repository
        //Utiliza o material do arquivo Optional(.get) como o body do request body
        parkingSpotService.delete(parkingSpotOptional.get());
        return ResponseEntity.status(HttpStatus.OK).body("Parking Spot deleted successfully!");
    }

    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @PutMapping
    public ResponseEntity<Object> updateParkingSpot (@PathVariable(value = "id") UUID id,
                                                     @RequestBody @Valid ParkingSpotDtos parkingSpotDtos)
                                                    //Passa o ID e um Request Body no formato Dto para garantir que
                                                     //o arquivo está vindo corretamente
    {
        Optional<ParkingSpot> parkingSpotOptional = parkingSpotService.findById(id); //Acha o arquivo pelo findById
        if (!parkingSpotOptional.isPresent())
        {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Parking Spot not found");
        }
        var parkingSpot = new ParkingSpot();                        //Cria um arquivo parkingSpot normal
        BeanUtils.copyProperties(parkingSpotDtos, parkingSpot);     //Converte o Dto revisado para o arquivo parking
        parkingSpot.setId(parkingSpotOptional.get().getId());       //Seta os atributos que continuam intactos
        parkingSpot.setRegistrationDate(parkingSpotOptional.get().getRegistrationDate());
        return ResponseEntity.status(HttpStatus.OK).body(parkingSpotService.save(parkingSpot));
                                    //Utiliza o save do Service passando o arquivo normal com tudo pronto
    }

}

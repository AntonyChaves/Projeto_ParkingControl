package com.API.parkingcontrol.Repository;

import com.API.parkingcontrol.Model.ParkingSpot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository                                                                           //UUID é a primary key
public interface ParkingSportRepository extends JpaRepository<ParkingSpot, UUID> {

    //Utiliza um método da JPA repository para verificar se essa placa já existe
    boolean existsByLicensePlateCar(String licensePlateCar);

    //Utiliza um método da JPA repository para verificar se já existe uma vaga com esse número preenchida
    boolean existsByParkingSpotNumber(String parkingSpotNumber);

    //Utiliza um método da JPA repository para verificar se essa vaga já foi registrada para outro morador
    boolean existsByApartmentAndBlock(String apartment, String block);

}
